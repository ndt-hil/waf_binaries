#! /usr/bin/env python
# encoding: utf-8
# Thomas Nagy, 2011 (ita)

from waflib import Logs
Logs.warn('This tool has been merged to the main library, remove the references to "add_objects"')

